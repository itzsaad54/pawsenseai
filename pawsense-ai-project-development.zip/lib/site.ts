import raw from './site.json'

export type Metrics = {
  epochs?: number
  batch_size?: number
  best_val_accuracy?: number
  test_accuracy?: number
  test_loss?: number
  precision?: number
  recall?: number
  f1_score?: number
  parameters?: number
  test_images?: number
}

export type Prediction = {
  image: string
  label: string
  predicted: string
  confidence: number
}

export type SiteData = {
  project: { name: string; title: string; tagline: string; author: string; course: string }
  links: Record<
    'github' | 'report' | 'slides' | 'youtube' | 'linkedin' | 'weights' | 'dataset',
    string
  >
  dataset: { name: string; total: string; split: string; input: string }
  metrics: Metrics | null
  confusion: { classes: string[]; matrix: number[][] } | null
  predictions: Prediction[]
}

export const site = raw as SiteData

export const CLASS_NAMES = ['Cat', 'Dog'] as const
export const INPUT_SIZE = 150
export const DEFAULT_THRESHOLD = 0.7

export function isLinkReady(url: string | undefined) {
  return Boolean(url && url.startsWith('http') && !/YOUR_|VIDEO_ID/.test(url))
}

export function pct(value: number | undefined, digits = 2) {
  return typeof value === 'number' ? `${(value * 100).toFixed(digits)}%` : null
}
