import type * as TF from '@tensorflow/tfjs'
import { INPUT_SIZE } from './site'

export type LoadedModel = {
  tf: typeof TF
  model: TF.Sequential
}

export class ModelUnavailableError extends Error {}

function buildModel(tf: typeof TF) {
  const L = tf.layers
  const m = tf.sequential()
  const conv = (filters: number, first = false) =>
    L.conv2d({
      filters,
      kernelSize: 3,
      activation: 'relu',
      ...(first ? { inputShape: [INPUT_SIZE, INPUT_SIZE, 3] } : {}),
    })
  const pool = () => L.maxPooling2d({ poolSize: 2, strides: 2 })
  ;[
    conv(32, true),
    conv(64),
    pool(),
    conv(64),
    conv(128),
    pool(),
    conv(128),
    conv(256),
    L.globalAveragePooling2d({ dataFormat: 'channelsLast' }),
    L.dense({ units: 1024, activation: 'relu' }),
    L.dense({ units: 2, activation: 'softmax' }),
  ].forEach((layer) => m.add(layer))
  return m
}

export async function loadModel(): Promise<LoadedModel> {
  const manifestRes = await fetch('/model/manifest.json')
  if (!manifestRes.ok) throw new ModelUnavailableError('Model weights have not been exported yet.')
  const manifest = (await manifestRes.json()) as { shapes: number[][] }

  const weightsRes = await fetch('/model/weights.bin')
  if (!weightsRes.ok) throw new ModelUnavailableError('weights.bin is missing.')
  const f32 = new Float32Array(await weightsRes.arrayBuffer())

  const tf = await import('@tensorflow/tfjs')
  await tf.ready()
  const model = buildModel(tf)

  let offset = 0
  model.setWeights(
    manifest.shapes.map((shape) => {
      const n = shape.reduce((a, b) => a * b, 1)
      const t = tf.tensor(f32.subarray(offset, offset + n), shape)
      offset += n
      return t
    }),
  )
  tf.tidy(() => {
    model.predict(tf.zeros([1, INPUT_SIZE, INPUT_SIZE, 3]))
  })
  return { tf, model }
}

export async function classify({ tf, model }: LoadedModel, image: HTMLImageElement) {
  const start = performance.now()
  const output = tf.tidy(() => {
    const input = tf.browser
      .fromPixels(image, 3)
      .resizeBilinear([INPUT_SIZE, INPUT_SIZE], false, true)
      .toFloat()
      .div(255)
      .expandDims(0)
    return model.predict(input) as TF.Tensor
  })
  const probs = Array.from(await output.data())
  output.dispose()
  return { probs, ms: performance.now() - start }
}
