import { CodeSection } from '@/components/code-section'
import { DatasetSection } from '@/components/dataset-section'
import { Deliverables } from '@/components/deliverables'
import { Hero } from '@/components/hero'
import { LiveDemo } from '@/components/live-demo'
import { ModelSection } from '@/components/model-section'
import { SectionHeading } from '@/components/section-heading'
import { SiteHeader } from '@/components/site-header'
import { site } from '@/lib/site'

export default function Page() {
  return (
    <>
      <SiteHeader />
      <main>
        <Hero />
        <Deliverables />
        <section id="demo" className="scroll-mt-20 border-t border-border">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-20">
            <SectionHeading
              eyebrow="02 — Live demo"
              title="Is it a cat or a dog?"
              description="Upload, drag in, or paste any photo. The trained network classifies it on your device in milliseconds."
            />
            <div className="mt-10">
              <LiveDemo />
            </div>
          </div>
        </section>
        <DatasetSection />
        <ModelSection />
        <CodeSection />
      </main>
      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p>
            {site.project.name} · {site.project.author}
          </p>
          <p>
            Machine-readable project data:{' '}
            <a href="/project.json" className="font-mono text-foreground underline underline-offset-4">
              /project.json
            </a>
          </p>
        </div>
      </footer>
    </>
  )
}
