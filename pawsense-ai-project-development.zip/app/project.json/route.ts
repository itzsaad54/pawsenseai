import { site } from '@/lib/site'

export function GET() {
  return Response.json({
    ...site,
    demo: { weights: '/model/weights.bin', manifest: '/model/manifest.json', input: [150, 150, 3], classes: ['Cat', 'Dog'] },
  })
}
