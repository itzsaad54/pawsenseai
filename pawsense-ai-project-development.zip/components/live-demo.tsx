'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import useSWR from 'swr'
import { Cpu, ImageUp, Loader, RotateCcw, ShieldCheck, TriangleAlert } from 'lucide-react'
import { classify, loadModel, ModelUnavailableError } from '@/lib/cnn'
import { CLASS_NAMES, DEFAULT_THRESHOLD } from '@/lib/site'
import { cn } from '@/lib/utils'

type Result = { id: number; src: string; probs: number[]; ms: number }

const SAMPLES = [
  { src: '/samples/try-cat.png', label: 'Sample cat' },
  { src: '/samples/try-dog.png', label: 'Sample dog' },
]

export function LiveDemo() {
  const { data: loaded, error, isLoading } = useSWR('cnn-model', loadModel, {
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
    shouldRetryOnError: false,
  })
  const [preview, setPreview] = useState<string | null>(null)
  const [current, setCurrent] = useState<Result | null>(null)
  const [history, setHistory] = useState<Result[]>([])
  const [threshold, setThreshold] = useState(DEFAULT_THRESHOLD)
  const [message, setMessage] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [dragging, setDragging] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const counter = useRef(0)

  const run = useCallback(
    (src: string) => {
      setMessage(null)
      setPreview(src)
      setCurrent(null)
      if (!loaded) {
        setMessage('The live model is not available on this deployment yet.')
        return
      }
      const img = new Image()
      img.crossOrigin = 'anonymous'
      img.onload = async () => {
        setBusy(true)
        try {
          const { probs, ms } = await classify(loaded, img)
          const result = { id: ++counter.current, src, probs, ms }
          setCurrent(result)
          setHistory((h) => [result, ...h].slice(0, 6))
        } catch (e) {
          setMessage(`Prediction failed: ${(e as Error).message}`)
        } finally {
          setBusy(false)
        }
      }
      img.onerror = () => setMessage('That file could not be read as an image.')
      img.src = src
    },
    [loaded],
  )

  const handleFile = useCallback(
    (file: File | undefined) => {
      if (!file) return
      if (!file.type.startsWith('image/')) {
        setMessage('Please choose an image file (JPG, PNG or WebP).')
        return
      }
      run(URL.createObjectURL(file))
    },
    [run],
  )

  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => handleFile(Array.from(e.clipboardData?.files ?? [])[0])
    window.addEventListener('paste', onPaste)
    return () => window.removeEventListener('paste', onPaste)
  }, [handleFile])

  const unavailable = Boolean(error)
  const top = current ? (current.probs[1] > current.probs[0] ? 1 : 0) : null
  const confident = current && top !== null && current.probs[top] >= threshold

  return (
    <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
      <div className="flex min-w-0 flex-col gap-4">
        <ModelStatus loading={isLoading} ready={Boolean(loaded)} error={error} />

        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault()
            setDragging(true)
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault()
            setDragging(false)
            handleFile(e.dataTransfer.files[0])
          }}
          className={cn(
            'relative flex min-h-64 w-full flex-col items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed bg-card p-4 sm:min-h-80 sm:p-6 text-center transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring',
            dragging ? 'border-accent bg-accent/5' : 'border-border hover:border-foreground/30',
          )}
        >
          {preview ? (
            // eslint-disable-next-line @next/next/no-img-element -- blob: URLs from user uploads cannot go through next/image
            <img src={preview} alt="Image selected for classification" className="max-h-72 w-auto rounded-xl object-contain" />
          ) : (
            <>
              <span className="flex size-14 items-center justify-center rounded-full bg-secondary">
                <ImageUp className="size-6" aria-hidden="true" />
              </span>
              <span className="mt-4 font-medium">Drop a cat or dog photo here</span>
              <span className="mt-1 text-sm text-muted-foreground">or click to browse · you can also paste an image</span>
            </>
          )}
          {busy && (
            <span className="absolute inset-0 flex items-center justify-center bg-card/70 backdrop-blur-sm">
              <Loader className="size-6 animate-spin" aria-hidden="true" />
              <span className="sr-only">Classifying</span>
            </span>
          )}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="sr-only"
          aria-label="Upload an image"
          onChange={(e) => {
            handleFile(e.target.files?.[0])
            e.target.value = ''
          }}
        />

        <div className="flex flex-wrap items-center gap-3">
          <span className="text-sm text-muted-foreground">No photo handy?</span>
          {SAMPLES.map((s) => (
            <button
              key={s.src}
              type="button"
              onClick={() => run(s.src)}
              disabled={!loaded || busy}
              className="flex items-center gap-2 rounded-lg border border-border bg-card py-1 pr-3 pl-1 text-sm transition-colors hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-50"
            >
              {/* eslint-disable-next-line @next/next/no-img-element -- tiny thumbnail */}
              <img src={s.src} alt="" className="size-7 rounded-md object-cover" />
              {s.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex min-w-0 flex-col gap-4">
        <div className="rounded-2xl border border-border bg-card p-6" aria-live="polite">
          <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Result</p>
          {current && top !== null ? (
            <>
              <p className="mt-3 text-3xl font-semibold tracking-tight">
                {confident ? `It's a ${CLASS_NAMES[top]}` : 'Not sure'}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                {confident
                  ? `${(current.probs[top] * 100).toFixed(1)}% confident · ${current.ms.toFixed(0)} ms in your browser`
                  : `Top guess ${CLASS_NAMES[top]} at ${(current.probs[top] * 100).toFixed(1)}% is below your ${Math.round(threshold * 100)}% threshold. The image may not contain a cat or dog.`}
              </p>
              <ul className="mt-6 flex flex-col gap-3">
                {CLASS_NAMES.map((name, i) => (
                  <li key={name} className="grid grid-cols-[3rem_1fr_3.5rem] items-center gap-3 text-sm">
                    <span className="font-medium">{name}</span>
                    <span className="h-2.5 overflow-hidden rounded-full bg-secondary">
                      <span
                        className={cn('block h-full rounded-full transition-[width] duration-500', i === top ? 'bg-accent' : 'bg-foreground/25')}
                        style={{ width: `${(current.probs[i] * 100).toFixed(1)}%` }}
                      />
                    </span>
                    <span className="text-right font-mono tabular-nums">{(current.probs[i] * 100).toFixed(1)}%</span>
                  </li>
                ))}
              </ul>
            </>
          ) : (
            <p className="mt-3 leading-relaxed text-muted-foreground">
              {message ??
                (unavailable
                  ? 'Live predictions turn on once the trained weights are exported to public/model/.'
                  : 'Upload a photo to see the prediction and per-class confidence.')}
            </p>
          )}
          {current && message && <p className="mt-4 text-sm text-destructive">{message}</p>}
        </div>

        <div className="rounded-2xl border border-border bg-card p-6">
          <div className="flex items-center justify-between">
            <label htmlFor="threshold" className="text-sm font-medium">
              Confidence threshold
            </label>
            <span className="font-mono text-sm tabular-nums">{Math.round(threshold * 100)}%</span>
          </div>
          <input
            id="threshold"
            type="range"
            min={0.5}
            max={0.95}
            step={0.05}
            value={threshold}
            onChange={(e) => setThreshold(Number(e.target.value))}
            className="mt-3 w-full accent-[var(--accent)]"
          />
          <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
            Predictions below this value are reported as &ldquo;Not sure&rdquo; instead of forcing a label on
            out-of-distribution images.
          </p>
        </div>

        {history.length > 0 && (
          <div className="rounded-2xl border border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">This session</p>
              <button
                type="button"
                onClick={() => setHistory([])}
                className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
              >
                <RotateCcw className="size-3.5" aria-hidden="true" />
                Clear
              </button>
            </div>
            <ul className="mt-4 grid grid-cols-3 gap-3">
              {history.map((h) => {
                const k = h.probs[1] > h.probs[0] ? 1 : 0
                return (
                  <li key={h.id} className="overflow-hidden rounded-lg border border-border">
                    {/* eslint-disable-next-line @next/next/no-img-element -- user upload thumbnail */}
                    <img src={h.src} alt={`Classified as ${CLASS_NAMES[k]}`} className="aspect-square w-full object-cover" />
                    <p className="px-2 py-1.5 text-xs">
                      <span className="font-medium">{CLASS_NAMES[k]}</span>{' '}
                      <span className="font-mono text-muted-foreground">{(h.probs[k] * 100).toFixed(0)}%</span>
                    </p>
                  </li>
                )
              })}
            </ul>
          </div>
        )}

        <p className="flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
          <ShieldCheck className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          Inference runs 100% in your browser with TensorFlow.js. Images are never uploaded to a server.
        </p>
      </div>
    </div>
  )
}

function ModelStatus({ loading, ready, error }: { loading: boolean; ready: boolean; error: unknown }) {
  if (loading) {
    return (
      <p className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-3 text-sm">
        <Loader className="size-4 animate-spin" aria-hidden="true" />
        Loading the CNN weights into your browser...
      </p>
    )
  }
  if (ready) {
    return (
      <p className="flex items-center gap-2 rounded-xl border border-success/30 bg-success/10 px-4 py-3 text-sm text-success">
        <Cpu className="size-4" aria-hidden="true" />
        Model ready — 8 layers, 150 x 150 input, running locally.
      </p>
    )
  }
  const notExported = error instanceof ModelUnavailableError
  return (
    <div className="flex items-start gap-3 rounded-xl border border-warning/30 bg-warning/10 px-4 py-3 text-sm">
      <TriangleAlert className="mt-0.5 size-4 shrink-0 text-warning" aria-hidden="true" />
      <div>
        <p className="font-medium text-warning">Live model not deployed yet</p>
        <p className="mt-1 leading-relaxed text-muted-foreground">
          {notExported ? (
            <>
              After training, run <code className="break-all font-mono text-foreground">python ml/scripts/export_web_model.py</code>{' '}
              and push — this demo switches on automatically.
            </>
          ) : (
            `The model could not be loaded: ${(error as Error)?.message ?? 'unknown error'}`
          )}
        </p>
      </div>
    </div>
  )
}
