import Image from 'next/image'
import { existsSync } from 'node:fs'
import path from 'node:path'
import { SectionHeading } from '@/components/section-heading'
import { site, pct } from '@/lib/site'

const LAYERS = [
  { name: 'Input', detail: '150 x 150 x 3', params: 0 },
  { name: 'Conv2D 32', detail: '3x3, ReLU', params: 896 },
  { name: 'Conv2D 64', detail: '3x3, ReLU', params: 18496 },
  { name: 'MaxPool', detail: '2x2', params: 0 },
  { name: 'Conv2D 64', detail: '3x3, ReLU', params: 36928 },
  { name: 'Conv2D 128', detail: '3x3, ReLU', params: 73856 },
  { name: 'MaxPool', detail: '2x2', params: 0 },
  { name: 'Conv2D 128', detail: '3x3, ReLU', params: 147584 },
  { name: 'Conv2D 256', detail: '3x3, ReLU', params: 295168 },
  { name: 'GlobalAvgPool', detail: '256 features', params: 0 },
  { name: 'Dense 1024', detail: 'ReLU', params: 263168 },
  { name: 'Dense 2', detail: 'Softmax', params: 2050 },
]

const TRAINING = [
  ['Optimizer', 'RMSprop, learning rate 0.001'],
  ['Loss', 'Sparse categorical cross-entropy'],
  ['Epochs', String(site.metrics?.epochs ?? 10)],
  ['Batch size', String(site.metrics?.batch_size ?? 64)],
  ['Checkpointing', 'Best validation accuracy is saved to model.keras'],
  ['Framework', 'TensorFlow / Keras, exported to TensorFlow.js'],
]

function publicAsset(file: string) {
  return existsSync(path.join(process.cwd(), 'public', 'assets', file)) ? `/assets/${file}` : null
}

export function ModelSection() {
  const m = site.metrics
  const total = LAYERS.reduce((a, l) => a + l.params, 0)
  const metrics = [
    { label: 'Test accuracy', value: pct(m?.test_accuracy) },
    { label: 'Precision', value: pct(m?.precision) },
    { label: 'Recall', value: pct(m?.recall) },
    { label: 'F1 score', value: pct(m?.f1_score) },
    { label: 'Best val accuracy', value: pct(m?.best_val_accuracy) },
    { label: 'Test loss', value: typeof m?.test_loss === 'number' ? m.test_loss.toFixed(4) : null },
  ]
  const curves = publicAsset('training_curves.png')
  const confusionImg = publicAsset('confusion_matrix.png')

  return (
    <section id="model" className="scroll-mt-20 border-t border-border bg-secondary/40">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-20">
        <SectionHeading
          eyebrow="04 — Model & results"
          title="A compact CNN trained from scratch"
          description="Six convolution layers, two pooling stages and a global average pool keep the network small enough to run in a browser tab, with no transfer learning."
        />

        <div className="mt-10 grid gap-6 lg:grid-cols-[1.3fr_1fr]">
          <div className="rounded-2xl border border-border bg-card p-6">
            <div className="flex items-baseline justify-between">
              <h3 className="font-semibold">Architecture</h3>
              <span className="font-mono text-xs text-muted-foreground">{total.toLocaleString('en-US')} params</span>
            </div>
            <ol className="mt-5 flex flex-col">
              {LAYERS.map((layer, i) => (
                <li
                  key={`${layer.name}-${i}`}
                  className="grid grid-cols-[1.5rem_1fr_auto] items-center gap-3 border-b border-border/70 py-2.5 text-sm last:border-0"
                >
                  <span className="font-mono text-xs text-muted-foreground">{i}</span>
                  <span>
                    <span className="font-medium">{layer.name}</span>{' '}
                    <span className="text-muted-foreground">· {layer.detail}</span>
                  </span>
                  <span className="font-mono text-xs tabular-nums text-muted-foreground">
                    {layer.params ? layer.params.toLocaleString('en-US') : '—'}
                  </span>
                </li>
              ))}
            </ol>
          </div>

          <div className="flex flex-col gap-6">
            <div className="rounded-2xl border border-border bg-card p-6">
              <h3 className="font-semibold">Training setup</h3>
              <dl className="mt-4 flex flex-col gap-3 text-sm">
                {TRAINING.map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-4">
                    <dt className="text-muted-foreground">{k}</dt>
                    <dd className="text-right font-medium">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="rounded-2xl border border-border bg-card p-6">
              <div className="flex items-baseline justify-between">
                <h3 className="font-semibold">Test-set metrics</h3>
                {m?.test_images && (
                  <span className="font-mono text-xs text-muted-foreground">{m.test_images} images</span>
                )}
              </div>
              {m ? (
                <dl className="mt-4 grid grid-cols-2 gap-4">
                  {metrics.map((x) => (
                    <div key={x.label}>
                      <dt className="text-xs text-muted-foreground">{x.label}</dt>
                      <dd className="text-xl font-semibold tabular-nums">{x.value ?? '—'}</dd>
                    </div>
                  ))}
                </dl>
              ) : (
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  Real numbers appear here after training. Run{' '}
                  <code className="font-mono text-foreground">python ml/scripts/evaluate.py</code> then{' '}
                  <code className="font-mono text-foreground">python ml/scripts/export_demo.py</code> — no
                  hand-typed results.
                </p>
              )}
            </div>
          </div>
        </div>

        {(site.confusion || curves || confusionImg) && (
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            {site.confusion && (
              <div className="rounded-2xl border border-border bg-card p-6">
                <h3 className="font-semibold">Confusion matrix</h3>
                <table className="mt-4 w-full text-center text-sm">
                  <thead>
                    <tr>
                      <th className="p-2 text-left text-xs font-normal text-muted-foreground">True \ Pred</th>
                      {site.confusion.classes.map((c) => (
                        <th key={c} className="p-2 font-medium">{c}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {site.confusion.matrix.map((row, i) => (
                      <tr key={site.confusion!.classes[i]}>
                        <th className="p-2 text-left font-medium">{site.confusion!.classes[i]}</th>
                        {row.map((v, j) => (
                          <td key={j} className={i === j ? 'rounded-md bg-accent/20 p-3 font-semibold' : 'p-3'}>
                            {v}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {curves && (
              <figure className="rounded-2xl border border-border bg-card p-6">
                <Image src={curves} alt="Training and validation accuracy and loss per epoch" width={1000} height={400} className="h-auto w-full" />
                <figcaption className="mt-3 text-sm text-muted-foreground">Training curves</figcaption>
              </figure>
            )}
          </div>
        )}

        {site.predictions.length > 0 && (
          <div className="mt-6 rounded-2xl border border-border bg-card p-6">
            <h3 className="font-semibold">Predictions on held-out test images</h3>
            <ul className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {site.predictions.map((p) => {
                const correct = p.label === p.predicted
                return (
                  <li key={p.image} className="overflow-hidden rounded-xl border border-border">
                    <Image src={`/${p.image}`} alt={`Test image of a ${p.label}`} width={300} height={300} className="aspect-square w-full object-cover" />
                    <div className="flex items-center justify-between px-3 py-2 text-xs">
                      <span>
                        <span className="font-medium">{p.predicted}</span>{' '}
                        <span className="font-mono text-muted-foreground">{(p.confidence * 100).toFixed(1)}%</span>
                      </span>
                      <span className={correct ? 'text-success' : 'text-destructive'}>{correct ? 'Correct' : `True: ${p.label}`}</span>
                    </div>
                  </li>
                )
              })}
            </ul>
          </div>
        )}
      </div>
    </section>
  )
}
