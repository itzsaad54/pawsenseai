import type { LucideIcon } from 'lucide-react'
import { ArrowUpRight } from 'lucide-react'
import { isLinkReady } from '@/lib/site'
import { cn } from '@/lib/utils'

type LinkCardProps = {
  title: string
  description: string
  href: string
  icon: LucideIcon
  required?: boolean
  meta?: string
  internal?: boolean
}

export function LinkCard({ title, description, href, icon: Icon, required, meta, internal }: LinkCardProps) {
  const ready = internal || isLinkReady(href)
  const content = (
    <>
      <div className="flex items-start justify-between gap-4">
        <span className="flex size-10 items-center justify-center rounded-lg bg-secondary text-foreground">
          <Icon className="size-5" aria-hidden="true" />
        </span>
        <div className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider">
          {required && <span className="rounded-md border border-border px-2 py-0.5 text-muted-foreground">Required</span>}
          <span
            className={cn(
              'flex items-center gap-1.5 rounded-md px-2 py-0.5',
              ready ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning',
            )}
          >
            <span className={cn('size-1.5 rounded-full', ready ? 'bg-success' : 'bg-warning')} aria-hidden="true" />
            {ready ? 'Ready' : 'Pending'}
          </span>
        </div>
      </div>
      <h3 className="mt-5 flex items-center gap-1.5 font-semibold">
        {title}
        {ready && (
          <ArrowUpRight
            className="size-4 text-muted-foreground transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
            aria-hidden="true"
          />
        )}
      </h3>
      <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{description}</p>
      {meta && <p className="mt-3 font-mono text-xs text-muted-foreground">{meta}</p>}
    </>
  )

  const className =
    'group flex h-full flex-col rounded-2xl border border-border bg-card p-5 transition-colors'

  if (!ready) {
    return (
      <div className={cn(className, 'opacity-80')} aria-disabled="true">
        {content}
      </div>
    )
  }

  return (
    <a
      href={href}
      target={internal ? undefined : '_blank'}
      rel="noreferrer"
      className={cn(className, 'hover:border-foreground/30')}
    >
      {content}
    </a>
  )
}
