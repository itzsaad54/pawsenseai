import { SectionHeading } from '@/components/section-heading'
import { site } from '@/lib/site'

const SPLITS = [
  { name: 'Train', share: 90, count: '~22,500' },
  { name: 'Validation', share: 5, count: '~1,250' },
  { name: 'Test', share: 5, count: '~1,250' },
]

const STEPS = [
  { title: 'Clean', body: 'Corrupt and non-JPEG files in the raw Kaggle dump are detected and skipped.' },
  { title: 'Split', body: 'Seeded 90 / 5 / 5 split per class, so every run is reproducible and balanced.' },
  { title: 'Resize', body: 'Images are resized bilinearly to 150 x 150 and scaled to the 0 to 1 range.' },
  { title: 'Batch', body: 'tf.data pipelines with shuffling, batching (64) and prefetching for fast training.' },
]

export function DatasetSection() {
  const { dataset } = site
  return (
    <section id="dataset" className="scroll-mt-20 border-t border-border">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-20">
        <SectionHeading
          eyebrow="03 — Dataset"
          title={dataset.name}
          description={`${dataset.total[0].toUpperCase()}${dataset.total.slice(1)}. Input resolution ${dataset.input}.`}
        />

        <div className="mt-10 rounded-2xl border border-border bg-card p-6">
          <div className="flex h-4 overflow-hidden rounded-full" role="img" aria-label="Train 90%, validation 5%, test 5%">
            <span className="bg-foreground" style={{ width: '90%' }} />
            <span className="bg-accent" style={{ width: '5%' }} />
            <span className="bg-success" style={{ width: '5%' }} />
          </div>
          <dl className="mt-6 grid gap-6 sm:grid-cols-3">
            {SPLITS.map((s, i) => (
              <div key={s.name} className="flex items-start gap-3">
                <span
                  className={['mt-1.5 size-2.5 rounded-full', ['bg-foreground', 'bg-accent', 'bg-success'][i]].join(' ')}
                  aria-hidden="true"
                />
                <div>
                  <dt className="text-sm text-muted-foreground">
                    {s.name} · {s.share}%
                  </dt>
                  <dd className="text-2xl font-semibold tracking-tight">{s.count}</dd>
                </div>
              </div>
            ))}
          </dl>
        </div>

        <ol className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((step, i) => (
            <li key={step.title} className="rounded-2xl border border-border bg-card p-5">
              <span className="font-mono text-xs text-muted-foreground">{String(i + 1).padStart(2, '0')}</span>
              <h3 className="mt-2 font-semibold">{step.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
