import { SectionHeading } from '@/components/section-heading'

const TREE = [
  ['ml/train.py', 'Train the CNN, save the best checkpoint and metrics'],
  ['ml/test.py', 'Load model.keras, smoke test, classify an image'],
  ['ml/model.py', 'Keras architecture (150 x 150 x 3 input)'],
  ['ml/data.py', 'Clean, split and load the Kaggle dataset'],
  ['ml/model.keras', 'Trained weights (single file)'],
  ['ml/scripts/', 'evaluate, export demo, export web model, slides, checks'],
  ['ml/docs/', 'Report, video script, LinkedIn post'],
  ['app/ · components/', 'This Next.js website'],
  ['public/model/', 'Browser weights used by the live demo'],
]

const COMMANDS = `# 1. install
pip install -r ml/requirements.txt

# 2. train (downloads/cleans the dataset first)
cd ml && python train.py --epochs 10 --batch_size 64

# 3. load the weights and test
python test.py --image path/to/cat.jpg

# 4. measure + publish results to the website
python scripts/evaluate.py
python scripts/export_demo.py
python scripts/export_web_model.py

# 5. final checklist before submitting
python scripts/check_project.py`

export function CodeSection() {
  return (
    <section id="code" className="scroll-mt-20 border-t border-border">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-20">
        <SectionHeading
          eyebrow="05 — Reproduce it"
          title="Train, test and deploy in five commands"
          description="Every number on this page is produced by the scripts in the repository — nothing is typed in by hand."
        />
        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          <pre className="overflow-x-auto rounded-2xl bg-primary p-6 font-mono text-sm leading-relaxed text-primary-foreground">
            <code>{COMMANDS}</code>
          </pre>
          <ul className="rounded-2xl border border-border bg-card p-2">
            {TREE.map(([file, desc]) => (
              <li key={file} className="flex flex-col gap-0.5 rounded-lg px-4 py-2.5 sm:flex-row sm:items-baseline sm:gap-4">
                <code className="shrink-0 font-mono text-sm font-medium sm:w-44">{file}</code>
                <span className="text-sm text-muted-foreground">{desc}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
