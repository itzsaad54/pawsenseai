import {
  Braces,
  CirclePlay,
  Database,
  Download,
  FileText,
  FolderGit2,
  Globe,
  Presentation,
  Share2,
  TestTubeDiagonal,
} from 'lucide-react'
import { LinkCard } from '@/components/link-card'
import { SectionHeading } from '@/components/section-heading'
import { site } from '@/lib/site'

export function Deliverables() {
  const { links } = site
  const repoFile = (path: string) => `${links.github}/blob/main/${path}`

  return (
    <section id="deliverables" className="scroll-mt-20 border-t border-border bg-secondary/40">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-20">
        <SectionHeading
          eyebrow="01 — Core deliverables"
          title="Everything required for review, in one place"
          description="Primary project components for evaluation. External cards open in a new tab."
        />
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <LinkCard
            required
            internal
            href="#demo"
            icon={Globe}
            title="Live Web App"
            description="Drop a photo and get a Cat or Dog prediction with confidence. Runs fully in your browser."
          />
          <LinkCard
            required
            href={links.github}
            icon={FolderGit2}
            title="GitHub Repository"
            description="Source code, training scripts, model weights, report and presentation."
          />
          <LinkCard
            required
            href={links.youtube}
            icon={CirclePlay}
            title="YouTube Presentation"
            description="Slide presentation with voiceover and a walkthrough of the live demo."
          />
          <LinkCard
            required
            href={links.linkedin}
            icon={Share2}
            title="LinkedIn Post"
            description="Public post announcing the project with repository and demo links."
          />
        </div>

        <h3 className="mt-14 text-lg font-semibold">Project resources</h3>
        <p className="mt-1 text-sm text-muted-foreground">Dataset, documents, code and model weights.</p>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <LinkCard
            href={links.dataset}
            icon={Database}
            title="Microsoft Cats vs Dogs (Kaggle)"
            description="Source of the ~25,000 labelled pet photos. Corrupt files are removed automatically."
          />
          <LinkCard
            href={links.report}
            icon={FileText}
            title="Project Report"
            description="Problem statement, dataset, architecture, training details, results and limitations."
          />
          <LinkCard
            href={links.slides}
            icon={Presentation}
            title="Presentation Slides (PPTX)"
            description="Auto-generated deck from measured metrics, covering problem to future work."
          />
          <LinkCard
            href={links.weights}
            icon={Download}
            title="Model Weights (.keras)"
            description="Trained Keras model — architecture and weights in a single file."
            meta="ml/model.keras · ~3 MB"
          />
          <LinkCard
            href={repoFile('ml/train.py')}
            icon={Braces}
            title="Training Script"
            description="Data preparation, model build, checkpointing and test evaluation."
            meta="ml/train.py"
          />
          <LinkCard
            href={repoFile('ml/test.py')}
            icon={TestTubeDiagonal}
            title="Test / Inference Script"
            description="Loads the weights, runs a smoke test, and classifies any image you pass in."
            meta="python test.py --image cat.jpg"
          />
        </div>
      </div>
    </section>
  )
}
