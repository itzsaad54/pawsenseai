import Image from 'next/image'
import { ArrowRight } from 'lucide-react'
import { site, pct } from '@/lib/site'

export function Hero() {
  const m = site.metrics
  const stats = [
    { value: pct(m?.test_accuracy) ?? 'Pending', label: 'Test accuracy' },
    { value: m?.parameters ? `${(m.parameters / 1e6).toFixed(2)} M` : '~0.84 M', label: 'Parameters' },
    { value: '~25,000', label: 'Training images' },
    { value: '2', label: 'Classes' },
  ]

  return (
    <section id="top" className="mx-auto max-w-6xl px-4 pt-12 pb-16 sm:px-6 md:pt-20">
      <div className="grid items-center gap-10 lg:grid-cols-[1.1fr_1fr]">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 font-mono text-xs uppercase tracking-wider text-muted-foreground">
            <span className="size-1.5 rounded-full bg-accent" aria-hidden="true" />
            {site.project.course}
          </p>
          <h1 className="mt-5 text-balance text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl md:text-6xl">
            {site.project.title}
          </h1>
          <p className="mt-5 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            {site.project.tagline} Every link for this project is collected on this page.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#demo"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
            >
              Try the live demo
              <ArrowRight className="size-4" aria-hidden="true" />
            </a>
            <a
              href="#deliverables"
              className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-5 py-3 text-sm font-medium transition-colors hover:bg-secondary"
            >
              View all links
            </a>
          </div>
        </div>
        <div className="relative overflow-hidden rounded-2xl border border-border bg-card">
          <Image
            src="/images/hero.png"
            alt="A tabby cat and a golden retriever puppy sitting side by side"
            width={1200}
            height={800}
            priority
            className="aspect-[4/3] h-auto w-full object-cover"
          />
          <div className="absolute inset-x-4 bottom-4 flex items-center justify-between rounded-xl bg-card/90 px-4 py-3 text-sm backdrop-blur">
            <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Prediction</span>
            <span className="font-medium">Cat · Dog — softmax over 2 classes</span>
          </div>
        </div>
      </div>

      <dl className="mt-14 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border bg-border md:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="bg-card px-6 py-5">
            <dt className="text-sm text-muted-foreground">{s.label}</dt>
            <dd className="mt-1 text-3xl font-semibold tracking-tight">{s.value}</dd>
          </div>
        ))}
      </dl>
    </section>
  )
}
