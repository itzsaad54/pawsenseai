import { PawPrint } from 'lucide-react'
import { site, isLinkReady } from '@/lib/site'

const NAV = [
  { href: '#deliverables', label: 'Deliverables' },
  { href: '#demo', label: 'Live demo' },
  { href: '#dataset', label: 'Dataset' },
  { href: '#model', label: 'Model' },
  { href: '#code', label: 'Code' },
]

export function SiteHeader() {
  const github = site.links.github
  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-6 px-4 sm:px-6">
        <a href="#top" className="flex items-center gap-2 font-semibold tracking-tight">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <PawPrint className="size-4" aria-hidden="true" />
          </span>
          {site.project.name}
        </a>
        <nav aria-label="Sections" className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          {NAV.map((item) => (
            <a key={item.href} href={item.href} className="transition-colors hover:text-foreground">
              {item.label}
            </a>
          ))}
        </nav>
        <a
          href={isLinkReady(github) ? github : '#deliverables'}
          target={isLinkReady(github) ? '_blank' : undefined}
          rel="noreferrer"
          className="rounded-lg bg-primary px-3.5 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
        >
          GitHub repo
        </a>
      </div>
    </header>
  )
}
