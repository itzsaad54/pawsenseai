"""Compute REAL metrics from model predictions on the test split.

    python scripts/evaluate.py
Writes results/metrics.json (accuracy, precision, recall, f1, confusion matrix)
and results/confusion_matrix.png. Nothing here is typed by hand.
"""
import argparse
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
CLASS_NAMES = ["Cat", "Dog"]


def compute_metrics(cm):
    """cm[i][j] = images of true class i predicted as j. Returns macro-averaged scores."""
    cm = np.asarray(cm, dtype=float)
    tp = np.diag(cm)
    precision = tp / np.maximum(cm.sum(axis=0), 1)
    recall = tp / np.maximum(cm.sum(axis=1), 1)
    f1 = 2 * precision * recall / np.maximum(precision + recall, 1e-12)
    return {
        "test_accuracy": float(tp.sum() / cm.sum()),
        "precision": float(precision.mean()),
        "recall": float(recall.mean()),
        "f1_score": float(f1.mean()),
        "per_class": {n: {"precision": float(precision[i]), "recall": float(recall[i]), "f1": float(f1[i])}
                      for i, n in enumerate(CLASS_NAMES)},
        "confusion_matrix": cm.astype(int).tolist(),
    }


def plot_confusion(cm, path):
    cm = np.asarray(cm)
    fig, ax = plt.subplots(figsize=(4.6, 4.2))
    ax.imshow(cm, cmap="Oranges")
    ax.set_xticks(range(2), CLASS_NAMES); ax.set_yticks(range(2), CLASS_NAMES)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title("Confusion matrix (test set)")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, int(cm[i, j]), ha="center", va="center", fontsize=16,
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--weights", default=str(ROOT / "model.keras"))
    p.add_argument("--data_dir", default=str(ROOT / "data" / "test"))
    a = p.parse_args()

    import tensorflow as tf
    from data import load_split
    model = tf.keras.models.load_model(a.weights)
    y_true, y_pred = [], []
    for x, y in load_split(a.data_dir, 64):
        y_true += y.numpy().tolist()
        y_pred += model.predict(x, verbose=0).argmax(1).tolist()
    cm = np.zeros((2, 2), dtype=int)
    for t, q in zip(y_true, y_pred):
        cm[t, q] += 1

    out = ROOT / "results"; out.mkdir(exist_ok=True)
    mpath = out / "metrics.json"
    metrics = json.loads(mpath.read_text()) if mpath.exists() else {}   # keep epochs, val acc, ...
    metrics.update(compute_metrics(cm))
    metrics["parameters"] = model.count_params()
    metrics["test_images"] = len(y_true)
    mpath.write_text(json.dumps(metrics, indent=2))
    plot_confusion(cm, out / "confusion_matrix.png")
    print(json.dumps({k: v for k, v in metrics.items() if k != "per_class"}, indent=2))


if __name__ == "__main__":
    main()
