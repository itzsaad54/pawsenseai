"""After training: fill the web page with real metrics + prediction examples.

    python scripts/export_demo.py --weights model.keras --data_dir data/test --n 8
"""
import argparse
import json
import random
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import numpy as np
import tensorflow as tf
from PIL import Image

from data import load_image, load_split
from model import CLASS_NAMES

SITE_JS = ROOT.parent / "lib" / "site.json"


def read_site():
    txt = SITE_JS.read_text()
    return json.loads(txt[txt.index("{"): txt.rindex("}") + 1])


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--weights", default=str(ROOT / "model.keras"))
    p.add_argument("--data_dir", default=str(ROOT / "data" / "test"))
    p.add_argument("--n", type=int, default=8, help="examples (half cats, half dogs)")
    p.add_argument("--seed", type=int, default=7)
    a = p.parse_args()

    model = tf.keras.models.load_model(a.weights)
    rng = random.Random(a.seed)
    out_dir = ROOT.parent / "public" / "samples"
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("*.jpg"):
        old.unlink()

    preds = []
    for folder, label in (("cats", "Cat"), ("dogs", "Dog")):
        files = sorted((Path(a.data_dir) / folder).glob("*.jpg"))
        for i, f in enumerate(rng.sample(files, a.n // 2)):
            probs = model.predict(load_image(f), verbose=0)[0]
            k = int(np.argmax(probs))
            name = f"{folder}_{i}.jpg"
            Image.open(f).convert("RGB").resize((300, 300)).save(out_dir / name, quality=85)
            preds.append({"image": f"samples/{name}", "label": label,
                          "predicted": CLASS_NAMES[k], "confidence": round(float(probs[k]), 4)})

    # confusion matrix on the full test split: rows = true, cols = predicted
    cm = [[0, 0], [0, 0]]
    for x, y in load_split(a.data_dir, 64):
        for t, q in zip(y.numpy(), model.predict(x, verbose=0).argmax(1)):
            cm[int(t)][int(q)] += 1

    site = read_site()
    site["confusion"] = {"classes": CLASS_NAMES, "matrix": cm}
    site["predictions"] = preds
    metrics = ROOT / "results" / "metrics.json"
    if metrics.exists():
        site["metrics"] = json.loads(metrics.read_text())
    SITE_JS.write_text(json.dumps(site, indent=2) + "\n")
    assets = ROOT.parent / "public" / "assets"
    assets.mkdir(parents=True, exist_ok=True)
    for png in ("training_curves.png", "confusion_matrix.png"):
        if (ROOT / "results" / png).exists():
            shutil.copy(ROOT / "results" / png, assets / png)
    print(f"Done: {len(preds)} examples written to the website (lib/site.json + public/). Now commit and push.")


if __name__ == "__main__":
    main()
