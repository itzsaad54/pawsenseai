"""Pre-submission checklist. Run from the repo root:  python ml/scripts/check_project.py"""
import json
import re
import sys
from pathlib import Path

ML = Path(__file__).resolve().parent.parent
REPO = ML.parent
ok = True


def check(cond, msg):
    global ok
    print(("[ OK ] " if cond else "[FAIL] ") + msg)
    ok &= bool(cond)


for f in ["ml/train.py", "ml/model.py", "ml/test.py", "ml/model.keras", "ml/requirements.txt",
          "README.md", "app/page.tsx", "lib/site.json", "ml/docs/REPORT.md"]:
    check((REPO / f).is_file(), f"{f} exists")

check((REPO / "public/model/weights.bin").is_file(), "public/model/weights.bin exists (live demo enabled)")
check((REPO / "public/model/manifest.json").is_file(), "public/model/manifest.json exists")
keras = ML / "model.keras"
check(keras.is_file() and keras.stat().st_size < 100e6, "ml/model.keras is under 100 MB (no Git LFS needed)")

mp = ML / "results/metrics.json"
check(mp.is_file() and "f1_score" in json.loads(mp.read_text()),
      "ml/results/metrics.json has real measured metrics (run ml/scripts/evaluate.py)")

readme = (REPO / "README.md").read_text()
check("python test.py" in readme, "README explains how to load/test the model")
check("YOUR_" not in readme, "README has no placeholder links")

site = json.loads((REPO / "lib/site.json").read_text())
for k, v in site["links"].items():
    check(v.startswith("http") and "YOUR_" not in v, f"site link '{k}' is filled in")
check(site.get("metrics") is not None, "lib/site.json contains metrics (run ml/scripts/export_demo.py)")

bad = [str(p) for p in ML.glob("*.py") if re.search(r"[A-Za-z]:[\\/]|/Users/|/home/", p.read_text())]
check(not bad, "no absolute paths in code" + (f" ({bad})" if bad else ""))

if keras.is_file():
    try:
        import tensorflow as tf
        shape = tf.keras.models.load_model(keras).input_shape
        check(shape[1:] == (150, 150, 3), f"model input shape is {shape} (report says 150x150x3)")
    except Exception as e:
        check(False, f"model.keras loads ({e})")

print("\nALL GOOD" if ok else "\nFix the [FAIL] items above.")
sys.exit(0 if ok else 1)
