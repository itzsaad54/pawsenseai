"""Dataset helpers: clean + split the raw Kaggle folder, and load splits."""
import random
from pathlib import Path

from PIL import Image

from model import IMG_SIZE

CLASSES = {"Cat": "cats", "Dog": "dogs"}   # raw folder name -> output folder name


def prepare_dataset(raw_dir, out_dir, seed=42, val_frac=0.05, test_frac=0.05):
    """Split raw PetImages/{Cat,Dog} into out_dir/{train,val,test}/{cats,dogs}.

    Corrupt or empty images (the Microsoft dataset has a few) are skipped.
    Every kept image is re-saved as an RGB JPEG so TensorFlow can always read it.
    """
    raw_dir, out_dir = Path(raw_dir), Path(out_dir)
    rng = random.Random(seed)
    for raw_name, out_name in CLASSES.items():
        src = raw_dir / raw_name
        if not src.is_dir():
            raise FileNotFoundError(f"Missing folder: {src}")
        good = []
        for f in sorted(src.iterdir()):
            try:
                if f.stat().st_size == 0:
                    continue
                with Image.open(f) as im:
                    im.verify()
                good.append(f)
            except Exception:
                continue
        rng.shuffle(good)
        n_val, n_test = int(len(good) * val_frac), int(len(good) * test_frac)
        splits = {
            "val": good[:n_val],
            "test": good[n_val:n_val + n_test],
            "train": good[n_val + n_test:],
        }
        for split, files in splits.items():
            dst = out_dir / split / out_name
            dst.mkdir(parents=True, exist_ok=True)
            kept = 0
            for f in files:
                try:
                    with Image.open(f) as im:
                        im.convert("RGB").save(dst / f"{f.stem}.jpg", quality=95)
                    kept += 1
                except Exception:
                    continue
            print(f"{out_name:5s} {split:5s}: {kept}")


def load_split(split_dir, batch_size=64, shuffle=False, seed=42):
    """Return a tf.data.Dataset of (images 0-255, int labels). cats=0, dogs=1."""
    import tensorflow as tf
    ds = tf.keras.utils.image_dataset_from_directory(
        split_dir,
        labels="inferred",
        label_mode="int",
        class_names=["cats", "dogs"],
        image_size=IMG_SIZE,
        batch_size=batch_size,
        shuffle=shuffle,
        seed=seed,
    )
    return ds.prefetch(tf.data.AUTOTUNE)


def load_image(path):
    """Load ONE image file as a float32 array of shape (1, 150, 150, 3), 0-255."""
    import tensorflow as tf
    raw = tf.io.read_file(str(path))
    img = tf.io.decode_image(raw, channels=3, expand_animations=False)
    img = tf.image.resize(img, IMG_SIZE)
    return tf.expand_dims(tf.cast(img, tf.float32), 0).numpy()
