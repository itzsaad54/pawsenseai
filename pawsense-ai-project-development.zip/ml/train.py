"""Train the Cats vs Dogs CNN and save model.keras.

Usage:
    python train.py --raw_dir PetImages            # first run: splits data, trains
    python train.py --epochs 10 --batch_size 64
"""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import tensorflow as tf

from data import prepare_dataset, load_split
from model import build_model


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--raw_dir", default="PetImages", help="folder containing Cat/ and Dog/")
    p.add_argument("--data_dir", default="data", help="where train/val/test splits are written")
    p.add_argument("--weights", default="model.keras", help="output model file")
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch_size", type=int, default=64)
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


def main():
    args = parse_args()
    tf.keras.utils.set_random_seed(args.seed)
    data_dir = Path(args.data_dir)

    if not (data_dir / "train").is_dir():
        print("Preparing dataset (one-time) ...")
        prepare_dataset(args.raw_dir, data_dir, seed=args.seed)

    train_ds = load_split(data_dir / "train", args.batch_size, shuffle=True, seed=args.seed)
    val_ds = load_split(data_dir / "val", args.batch_size)
    test_ds = load_split(data_dir / "test", args.batch_size)

    model = build_model()
    model.summary()

    ckpt = tf.keras.callbacks.ModelCheckpoint(
        args.weights, monitor="val_accuracy", mode="max", save_best_only=True, verbose=1
    )
    hist = model.fit(train_ds, validation_data=val_ds, epochs=args.epochs, callbacks=[ckpt])

    # Evaluate the BEST saved model on the untouched test split
    best = tf.keras.models.load_model(args.weights)
    test_loss, test_acc = best.evaluate(test_ds)
    results = {
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "best_val_accuracy": max(hist.history["val_accuracy"]),
        "test_accuracy": test_acc,
        "test_loss": test_loss,
        "parameters": best.count_params(),
    }
    Path("results").mkdir(exist_ok=True)
    Path("results/metrics.json").write_text(json.dumps(results, indent=2))
    Path("results/history.json").write_text(json.dumps(hist.history, indent=2))

    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    for a, key in zip(ax, ["accuracy", "loss"]):
        a.plot(hist.history[key], label="train")
        a.plot(hist.history[f"val_{key}"], label="validation")
        a.set_title(key); a.set_xlabel("epoch"); a.legend()
    fig.tight_layout()
    fig.savefig("results/training_curves.png", dpi=150)

    print(json.dumps(results, indent=2))
    print(f"Saved: {args.weights}, results/metrics.json, results/training_curves.png")


if __name__ == "__main__":
    main()
